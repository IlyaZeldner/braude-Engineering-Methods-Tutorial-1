package plugins.plantUML.models;

import java.util.ArrayList;
import java.util.List;

public class ActorData extends BaseWithSemanticsData {
    private List<String> stereotypes = new ArrayList<>();
    private boolean isInPackage;
    private boolean isBusiness;
    private String Uid;

    public ActorData(String name) {
        super(name);
        this.stereotypes = new ArrayList<>();
    }

    public List<String> getStereotypes() {
        if (stereotypes == null) {
            stereotypes = new ArrayList<>();
        }
        return stereotypes;
    }

    public void setStereotypes(List<String> stereotypes) {
        this.stereotypes = (stereotypes != null) ? stereotypes : new ArrayList<>();
    }

    public void addStereotype(String stereotype) {
        if (stereotypes == null) {
            stereotypes = new ArrayList<>();
        }
        stereotypes.add(stereotype);
    }

    public boolean isInPackage() {
        return isInPackage;
    }

    public void setInPackage(boolean isInPackage) {
        this.isInPackage = isInPackage;
    }

    public boolean isBusiness() {
        return isBusiness;
    }

    public void setBusiness(boolean isBusiness) {
        this.isBusiness = isBusiness;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }
}